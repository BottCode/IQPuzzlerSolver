# IQPuzzlerSolver
An artificial intelligence which solves IQ puzzler game.
